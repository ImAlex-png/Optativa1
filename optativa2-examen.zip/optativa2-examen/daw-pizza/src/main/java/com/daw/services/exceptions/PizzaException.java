package com.daw.services.exceptions;

public class PizzaException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2791539739625423049L;

	public PizzaException(String message) {
		super(message);
	}

}
