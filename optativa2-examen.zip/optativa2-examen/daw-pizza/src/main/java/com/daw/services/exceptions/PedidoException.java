package com.daw.services.exceptions;

public class PedidoException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3637820916404637424L;

	public PedidoException(String message) {
		super(message);
	}

}
