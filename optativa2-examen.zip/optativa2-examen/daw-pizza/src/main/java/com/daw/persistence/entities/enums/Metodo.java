package com.daw.persistence.entities.enums;

public enum Metodo {
	
	RECOGER, DOMICILIO, LOCAL

}
