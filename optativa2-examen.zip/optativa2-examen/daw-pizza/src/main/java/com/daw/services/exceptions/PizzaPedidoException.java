package com.daw.services.exceptions;

public class PizzaPedidoException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -470680027832869142L;

	public PizzaPedidoException(String message) {
		super(message);
	}

}
