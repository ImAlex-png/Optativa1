package com.daw.services.exceptions;

public class ClienteException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5814500915328687878L;

	public ClienteException(String message) {
		super(message);
	}

}
